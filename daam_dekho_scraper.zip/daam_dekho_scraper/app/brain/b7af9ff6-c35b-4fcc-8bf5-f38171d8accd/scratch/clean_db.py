import sqlite3
import os

db_path = r"d:\shubham\daam_dekho_final\daam_dekho_scraper\products.db"

def clean_db():
    if not os.path.exists(db_path):
        print(f"Error: {db_path} not found.")
        return

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Get all table names
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()

        for table_name in tables:
            name = table_name[0]
            if name == 'sqlite_sequence':
                continue
            print(f"Cleaning table: {name}")
            cursor.execute(f"DELETE FROM {name}")
            # Reset auto-increment if exists
            try:
                cursor.execute(f"DELETE FROM sqlite_sequence WHERE name='{name}'")
            except sqlite3.OperationalError:
                pass

        conn.commit()
        conn.execute("VACUUM")
        conn.close()
        print("Database cleaned successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    clean_db()
